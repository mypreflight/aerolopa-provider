"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var index_exports = {};
__export(index_exports, {
  handler: () => handler3
});
module.exports = __toCommonJS(index_exports);

// ../packages/aerolopa/layouts/src/lambda.ts
var import_node_crypto = require("node:crypto");

// ../packages/aerolopa/layouts/src/errors.ts
var ProviderError = class extends Error {
  static {
    __name(this, "ProviderError");
  }
  constructor(message) {
    super(message);
    this.name = new.target.name;
  }
};
var AerolopaUnavailableError = class extends ProviderError {
  static {
    __name(this, "AerolopaUnavailableError");
  }
  status = 502;
  code = "AEROLOPA_UNAVAILABLE";
  constructor() {
    super("AeroLOPA is unavailable.");
  }
};

// ../packages/aerolopa/layouts/src/logger.ts
var SEVERITY = {
  verbose: 10,
  debug: 20,
  log: 30,
  warn: 40,
  error: 50,
  fatal: 60
};
var DEFAULT_LEVEL = "log";
var PREFIX = "Aerolopa";
var plain = /* @__PURE__ */ __name((text) => text, "plain");
function ansi(open) {
  return (text) => `\x1B[${open}m${text}\x1B[39m`;
}
__name(ansi, "ansi");
var COLORS = {
  verbose: ansi("96"),
  debug: ansi("95"),
  log: ansi("32"),
  warn: ansi("33"),
  error: ansi("31"),
  fatal: /* @__PURE__ */ __name((text) => `\x1B[1m${text}\x1B[0m`, "fatal")
};
var CONTEXT_COLOR = ansi("38;5;3");
function isLevel(value) {
  return value in SEVERITY;
}
__name(isLevel, "isLevel");
function threshold() {
  const configured = (process.env.LOG_LEVEL ?? "").toLowerCase();
  return SEVERITY[isLevel(configured) ? configured : DEFAULT_LEVEL];
}
__name(threshold, "threshold");
function colored() {
  return process.stdout.isTTY === true && !process.env.NO_COLOR;
}
__name(colored, "colored");
function timestamp() {
  return (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "numeric",
    second: "numeric"
  });
}
__name(timestamp, "timestamp");
function format(level, context, message) {
  const paint = colored() ? COLORS[level] : plain;
  const contextPaint = colored() ? CONTEXT_COLOR : plain;
  const pid = paint(`[${PREFIX}] ${process.pid}  - `);
  const label = paint(level.toUpperCase().padStart(7, " "));
  return `${pid}${timestamp()} ${label} ${contextPaint(`[${context}] `)}${paint(message)}`;
}
__name(format, "format");
function write(level, context, message, stack) {
  if (SEVERITY[level] < threshold()) {
    return;
  }
  const stream = level === "error" || level === "fatal" ? process.stderr : process.stdout;
  stream.write(`${format(level, context, message)}
${stack ? `${stack}
` : ""}`);
}
__name(write, "write");
function describeError(error, depth = 3) {
  if (!(error instanceof Error)) {
    try {
      return `Non-error thrown: ${JSON.stringify(error)}`;
    } catch {
      return `Non-error thrown: ${String(error)}`;
    }
  }
  const head = `${error.name}: ${error.message}`;
  if (depth <= 1 || error.cause === void 0 || error.cause === null) {
    return head;
  }
  return `${head} (caused by: ${describeError(error.cause, depth - 1)})`;
}
__name(describeError, "describeError");
function stackOf(error) {
  return error instanceof Error ? error.stack : void 0;
}
__name(stackOf, "stackOf");
var Logger = class {
  constructor(context) {
    this.context = context;
  }
  context;
  static {
    __name(this, "Logger");
  }
  verbose(message) {
    write("verbose", this.context, message);
  }
  debug(message) {
    write("debug", this.context, message);
  }
  log(message) {
    write("log", this.context, message);
  }
  warn(message) {
    write("warn", this.context, message);
  }
  error(message, stack) {
    write("error", this.context, message, stack);
  }
  fatal(message, stack) {
    write("fatal", this.context, message, stack);
  }
};

// ../packages/aerolopa/layouts/src/parser/layout-index.parser.ts
var LOCATION_PATTERN = /<loc>([^<]+)<\/loc>/g;
var LAYOUT_SLUG_PATTERN = /^([a-z0-9]{2})-([a-z0-9]{2,6})(?:-(.+))?$/;
function parseLayoutIndex(sitemap) {
  const layouts = [];
  for (const match of sitemap.matchAll(LOCATION_PATTERN)) {
    const id = match[1].replace(/^https?:\/\/[^/]+\/?/, "");
    const parts = LAYOUT_SLUG_PATTERN.exec(id);
    if (!parts) {
      continue;
    }
    layouts.push({
      id,
      airlineIata: parts[1].toUpperCase(),
      aircraftIata: parts[2].toUpperCase(),
      variant: parts[3] ?? null
    });
  }
  return layouts;
}
__name(parseLayoutIndex, "parseLayoutIndex");

// ../packages/aerolopa/layouts/src/client.ts
var CACHE_TTL_MS = 864e5;
var LAYOUT_INDEX_KEY = "layouts";
var TIMEOUT_MS = 15e3;
var RETRIES = 2;
var BACKOFF_MS = 500;
var delay = /* @__PURE__ */ __name((ms) => new Promise((resolve) => setTimeout(resolve, ms)), "delay");
var AerolopaClient = class _AerolopaClient {
  static {
    __name(this, "AerolopaClient");
  }
  logger = new Logger(_AerolopaClient.name);
  baseUrl;
  userAgent;
  cache = /* @__PURE__ */ new Map();
  constructor(options) {
    this.baseUrl = options.baseUrl.replace(/\/+$/, "");
    this.userAgent = options.userAgent;
  }
  async listLayouts() {
    return this.cached(
      LAYOUT_INDEX_KEY,
      async () => parseLayoutIndex(await this.request(`${this.baseUrl}/sitemap.xml`, { Accept: "application/xml" }))
    );
  }
  async cached(key, produce) {
    const entry = this.cache.get(key);
    if (entry && entry.expiresAt > Date.now()) {
      this.logger.debug(`Serving ${key} from cache.`);
      return entry.value;
    }
    const value = await produce();
    this.cache.set(key, { value, expiresAt: Date.now() + CACHE_TTL_MS });
    return value;
  }
  async request(url, headers) {
    const startedAt = Date.now();
    const response = await this.fetchWithRetry(url, headers);
    if (!response.ok) {
      this.logger.warn(`AeroLOPA answered ${response.status} for ${url}.`);
      throw new AerolopaUnavailableError();
    }
    try {
      const body = await response.text();
      this.logger.debug(`Read ${body.length} bytes from ${url} in ${Date.now() - startedAt}ms.`);
      return body;
    } catch (error) {
      this.logger.warn(`Could not read the AeroLOPA response from ${url}: ${describeError(error)}`);
      throw new AerolopaUnavailableError();
    }
  }
  async fetchWithRetry(url, headers) {
    for (let attempt = 0; attempt <= RETRIES; attempt++) {
      try {
        return await fetch(url, {
          headers: { "User-Agent": this.userAgent, ...headers },
          signal: AbortSignal.timeout(TIMEOUT_MS)
        });
      } catch (error) {
        if (attempt === RETRIES) {
          this.logger.error(`Could not reach ${url} in ${RETRIES + 1} attempts: ${describeError(error)}`);
          throw new AerolopaUnavailableError();
        }
        const backoff = BACKOFF_MS * 2 ** attempt;
        this.logger.warn(
          `Attempt ${attempt + 1} to reach ${url} failed: ${describeError(error)}. Retrying in ${backoff}ms.`
        );
        await delay(backoff);
      }
    }
    throw new AerolopaUnavailableError();
  }
};

// ../packages/aerolopa/layouts/src/handler.ts
var logger = new Logger("LayoutsHandler");
async function handleRequest(client3) {
  const startedAt = Date.now();
  try {
    const layouts = await client3.listLayouts();
    const index = { count: layouts.length, layouts };
    logger.log(`Served ${index.count} layouts in ${Date.now() - startedAt}ms.`);
    return { statusCode: 200, body: index };
  } catch (error) {
    if (error instanceof ProviderError) {
      logger.warn(`Layout index lookup failed after ${Date.now() - startedAt}ms with ${error.status} ${error.code}.`);
      return {
        statusCode: error.status,
        body: {
          error: {
            code: error.code,
            message: error.message,
            status: error.status
          }
        }
      };
    }
    logger.error(
      `Layout index lookup crashed after ${Date.now() - startedAt}ms: ${describeError(error)}`,
      stackOf(error)
    );
    return {
      statusCode: 500,
      body: {
        error: {
          code: "INTERNAL_ERROR",
          message: "Layout index lookup failed.",
          status: 500
        }
      }
    };
  }
}
__name(handleRequest, "handleRequest");

// ../packages/aerolopa/layouts/src/function.ts
var DEFAULT_BASE_URL = "https://www.aerolopa.com";
var DEFAULT_USER_AGENT = "MyPreflight/1.0 (+https://mypreflight.io)";
var logger2 = new Logger("LayoutsFunction");
var client;
function resolveClient() {
  if (!client) {
    const baseUrl = process.env.AEROLOPA_API_HOST ?? DEFAULT_BASE_URL;
    client = new AerolopaClient({
      baseUrl,
      userAgent: process.env.AEROLOPA_USER_AGENT ?? DEFAULT_USER_AGENT
    });
    logger2.log(`Cold start. Reading layouts from ${baseUrl}.`);
  }
  return client;
}
__name(resolveClient, "resolveClient");
async function main() {
  const { statusCode, body } = await handleRequest(resolveClient());
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body
  };
}
__name(main, "main");

// ../packages/aerolopa/layouts/src/lambda.ts
var SECRET_HEADER = "x-require-whisk-auth";
var UNAUTHORIZED = {
  statusCode: 401,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    error: {
      code: "UNAUTHORIZED",
      message: "The X-Require-Whisk-Auth header is missing or wrong.",
      status: 401
    }
  })
};
function isAuthorized(received) {
  const secret = process.env.AEROLOPA_FUNCTION_SECRET ?? "";
  if (secret === "" || received === void 0) {
    return false;
  }
  const expected = Buffer.from(secret);
  const actual = Buffer.from(received);
  return expected.length === actual.length && (0, import_node_crypto.timingSafeEqual)(expected, actual);
}
__name(isAuthorized, "isAuthorized");
function createHandler(entry) {
  return async (event) => {
    if (!isAuthorized(event.headers?.[SECRET_HEADER])) {
      return UNAUTHORIZED;
    }
    const args = { ...event.queryStringParameters, __ow_method: event.requestContext.http.method.toLowerCase() };
    const { statusCode, headers, body } = await entry(args);
    return { statusCode, headers, body: typeof body === "string" ? body : JSON.stringify(body) };
  };
}
__name(createHandler, "createHandler");
var handler = createHandler(main);

// ../packages/aerolopa/seatmap/src/lambda.ts
var import_node_crypto2 = require("node:crypto");

// ../packages/aerolopa/seatmap/src/errors.ts
var ProviderError2 = class extends Error {
  static {
    __name(this, "ProviderError");
  }
  constructor(message) {
    super(message);
    this.name = new.target.name;
  }
};
var BadRequestError = class extends ProviderError2 {
  static {
    __name(this, "BadRequestError");
  }
  status = 400;
  code = "BAD_REQUEST";
};
var SeatMapNotFoundError = class extends ProviderError2 {
  static {
    __name(this, "SeatMapNotFoundError");
  }
  status = 404;
  code = "SEAT_MAP_NOT_FOUND";
  constructor(slug) {
    super(`Seat map for configuration ${slug} does not exist.`);
  }
};
var AerolopaUnavailableError2 = class extends ProviderError2 {
  static {
    __name(this, "AerolopaUnavailableError");
  }
  status = 502;
  code = "AEROLOPA_UNAVAILABLE";
  constructor() {
    super("AeroLOPA is unavailable.");
  }
};
var SeatMapUnreadableError = class extends ProviderError2 {
  static {
    __name(this, "SeatMapUnreadableError");
  }
  status = 502;
  code = "SEAT_MAP_UNREADABLE";
  constructor(slug) {
    super(`Seat map payload for configuration ${slug} could not be read.`);
  }
};

// ../packages/aerolopa/seatmap/src/logger.ts
var SEVERITY2 = {
  verbose: 10,
  debug: 20,
  log: 30,
  warn: 40,
  error: 50,
  fatal: 60
};
var DEFAULT_LEVEL2 = "log";
var PREFIX2 = "Aerolopa";
var plain2 = /* @__PURE__ */ __name((text) => text, "plain");
function ansi2(open) {
  return (text) => `\x1B[${open}m${text}\x1B[39m`;
}
__name(ansi2, "ansi");
var COLORS2 = {
  verbose: ansi2("96"),
  debug: ansi2("95"),
  log: ansi2("32"),
  warn: ansi2("33"),
  error: ansi2("31"),
  fatal: /* @__PURE__ */ __name((text) => `\x1B[1m${text}\x1B[0m`, "fatal")
};
var CONTEXT_COLOR2 = ansi2("38;5;3");
function isLevel2(value) {
  return value in SEVERITY2;
}
__name(isLevel2, "isLevel");
function threshold2() {
  const configured = (process.env.LOG_LEVEL ?? "").toLowerCase();
  return SEVERITY2[isLevel2(configured) ? configured : DEFAULT_LEVEL2];
}
__name(threshold2, "threshold");
function colored2() {
  return process.stdout.isTTY === true && !process.env.NO_COLOR;
}
__name(colored2, "colored");
function timestamp2() {
  return (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "numeric",
    second: "numeric"
  });
}
__name(timestamp2, "timestamp");
function format2(level, context, message) {
  const paint = colored2() ? COLORS2[level] : plain2;
  const contextPaint = colored2() ? CONTEXT_COLOR2 : plain2;
  const pid = paint(`[${PREFIX2}] ${process.pid}  - `);
  const label = paint(level.toUpperCase().padStart(7, " "));
  return `${pid}${timestamp2()} ${label} ${contextPaint(`[${context}] `)}${paint(message)}`;
}
__name(format2, "format");
function write2(level, context, message, stack) {
  if (SEVERITY2[level] < threshold2()) {
    return;
  }
  const stream = level === "error" || level === "fatal" ? process.stderr : process.stdout;
  stream.write(`${format2(level, context, message)}
${stack ? `${stack}
` : ""}`);
}
__name(write2, "write");
function describeError2(error, depth = 3) {
  if (!(error instanceof Error)) {
    try {
      return `Non-error thrown: ${JSON.stringify(error)}`;
    } catch {
      return `Non-error thrown: ${String(error)}`;
    }
  }
  const head = `${error.name}: ${error.message}`;
  if (depth <= 1 || error.cause === void 0 || error.cause === null) {
    return head;
  }
  return `${head} (caused by: ${describeError2(error.cause, depth - 1)})`;
}
__name(describeError2, "describeError");
function stackOf2(error) {
  return error instanceof Error ? error.stack : void 0;
}
__name(stackOf2, "stackOf");
var Logger2 = class {
  constructor(context) {
    this.context = context;
  }
  context;
  static {
    __name(this, "Logger");
  }
  verbose(message) {
    write2("verbose", this.context, message);
  }
  debug(message) {
    write2("debug", this.context, message);
  }
  log(message) {
    write2("log", this.context, message);
  }
  warn(message) {
    write2("warn", this.context, message);
  }
  error(message, stack) {
    write2("error", this.context, message, stack);
  }
  fatal(message, stack) {
    write2("fatal", this.context, message, stack);
  }
};

// ../packages/aerolopa/seatmap/src/parser/configuration-index.parser.ts
var LOCATION_PATTERN2 = /<loc>([^<]+)<\/loc>/g;
var CONFIGURATION_SLUG_PATTERN = /^([a-z0-9]{2})-([a-z0-9]{2,6})(?:-.+)?$/;
function parseConfigurationIndex(sitemap) {
  const configurations = [];
  for (const match of sitemap.matchAll(LOCATION_PATTERN2)) {
    const slug = match[1].replace(/^https?:\/\/[^/]+\/?/, "");
    const parts = CONFIGURATION_SLUG_PATTERN.exec(slug);
    if (!parts) {
      continue;
    }
    configurations.push({
      slug,
      airlineIata: parts[1].toUpperCase(),
      aircraftIata: parts[2].toUpperCase()
    });
  }
  return configurations;
}
__name(parseConfigurationIndex, "parseConfigurationIndex");

// ../packages/aerolopa/seatmap/src/parser/rsc-payload.parser.ts
var CHUNK_PATTERN = /self\.__next_f\.push\(\[1,("(?:[^"\\]|\\.)*")\]\)/g;
var SEAT_MAP_MARKER = '"seats":{';
function decodeRscPayload(raw) {
  if (!raw.includes("self.__next_f.push")) {
    return raw;
  }
  const chunks = [];
  for (const match of raw.matchAll(CHUNK_PATTERN)) {
    chunks.push(JSON.parse(match[1]));
  }
  return chunks.join("");
}
__name(decodeRscPayload, "decodeRscPayload");
function findObjectStart(payload, from) {
  let depth = 0;
  for (let index = from; index >= 0; index--) {
    const character = payload[index];
    if (character === "}") {
      depth++;
      continue;
    }
    if (character === "{") {
      if (depth === 0) {
        return index;
      }
      depth--;
    }
  }
  return -1;
}
__name(findObjectStart, "findObjectStart");
function findObjectEnd(payload, start) {
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < payload.length; index++) {
    const character = payload[index];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (character === "\\") {
        escaped = true;
      } else if (character === '"') {
        inString = false;
      }
      continue;
    }
    if (character === '"') {
      inString = true;
    } else if (character === "{") {
      depth++;
    } else if (character === "}") {
      depth--;
      if (depth === 0) {
        return index;
      }
    }
  }
  return -1;
}
__name(findObjectEnd, "findObjectEnd");
function extractSeatMapRecord(payload) {
  const marker = payload.indexOf(SEAT_MAP_MARKER);
  if (marker < 0) {
    return null;
  }
  const start = findObjectStart(payload, marker);
  if (start < 0) {
    return null;
  }
  const end = findObjectEnd(payload, start);
  if (end < 0) {
    return null;
  }
  try {
    return JSON.parse(payload.slice(start, end + 1));
  } catch {
    return null;
  }
}
__name(extractSeatMapRecord, "extractSeatMapRecord");

// ../packages/aerolopa/seatmap/src/types.ts
function transformComment(input) {
  return {
    slug: input.slug,
    comment: input.comment,
    sentiment: input.sentiment,
    severity: input.severity
  };
}
__name(transformComment, "transformComment");
function transformSeat(designator, input) {
  return {
    designator,
    x: input.x,
    y: input.y,
    width: input.w,
    height: input.h,
    rotation: input.rot,
    reversed: input.reverse,
    cabin: input.cabin,
    rating: input.rating,
    color: input.color,
    bookable: input.bookable,
    blocked: input.blocked,
    crewRest: input.crew_rest,
    windowStatus: input.window?.status ?? null,
    seatProduct: input.seat_product_name ?? input.seat_product,
    comments: (input.comments ?? []).map(transformComment)
  };
}
__name(transformSeat, "transformSeat");
function transformCabin(input) {
  return {
    code: input.cabin_type,
    name: input.cabin_class,
    seatCount: input.num_seats,
    rows: input.rows ?? null,
    pitch: input.pitch ?? null,
    width: input.width ?? null,
    recline: input.recline ?? null,
    description: input.seat_description ?? null
  };
}
__name(transformCabin, "transformCabin");
function transformSeatMap(input) {
  return {
    slug: input.aircraft_code,
    airlineIata: input.airline_iata,
    aircraftIata: input.iata_code,
    aircraftType: input.aircraft_type,
    aircraftTypeDisplayed: input.aircraft_type_displayed,
    manufacturer: input.aircraft_manufacturer,
    haulType: input.haul_type,
    isDualDeck: input.is_dual_deck,
    totalSeats: input.total_seats,
    lastUpdated: input.last_updated,
    seatCounts: input.seat_counts,
    canvas: { width: input.viewBox.width, height: input.viewBox.height },
    cabins: (input.cabins ?? []).map(transformCabin),
    assets: {
      image: input.image_url_cdn,
      imageNeutral: input.image_url_neutral_cdn,
      svg: input.svg_url,
      seatRects: input.seat_rects_url
    },
    seats: Object.entries(input.seats).map(([designator, seat]) => transformSeat(designator, seat))
  };
}
__name(transformSeatMap, "transformSeatMap");

// ../packages/aerolopa/seatmap/src/client.ts
var CACHE_TTL_MS2 = 864e5;
var CONFIGURATION_INDEX_KEY = "configurations";
var SEAT_MAP_MARKER2 = '"seats":{';
var TIMEOUT_MS2 = 15e3;
var RETRIES2 = 2;
var BACKOFF_MS2 = 500;
var delay2 = /* @__PURE__ */ __name((ms) => new Promise((resolve) => setTimeout(resolve, ms)), "delay");
var AerolopaClient2 = class _AerolopaClient {
  static {
    __name(this, "AerolopaClient");
  }
  logger = new Logger2(_AerolopaClient.name);
  baseUrl;
  userAgent;
  cache = /* @__PURE__ */ new Map();
  constructor(options) {
    this.baseUrl = options.baseUrl.replace(/\/+$/, "");
    this.userAgent = options.userAgent;
  }
  async getSeatMap(slug) {
    return this.cached(`seat-map:${slug}`, async () => {
      const record = extractSeatMapRecord(decodeRscPayload(await this.fetchSeatMapPayload(slug)));
      if (!record) {
        throw new SeatMapUnreadableError(slug);
      }
      return transformSeatMap(record);
    });
  }
  async listConfigurations() {
    return this.cached(
      CONFIGURATION_INDEX_KEY,
      async () => parseConfigurationIndex(await this.request(`${this.baseUrl}/sitemap.xml`, { Accept: "application/xml" }))
    );
  }
  async findConfigurations(airlineIata, aircraftIata) {
    const airline = airlineIata.toUpperCase();
    const aircraft = aircraftIata.toUpperCase();
    return (await this.listConfigurations()).filter(
      (configuration) => configuration.airlineIata === airline && configuration.aircraftIata === aircraft
    );
  }
  async cached(key, produce) {
    const entry = this.cache.get(key);
    if (entry && entry.expiresAt > Date.now()) {
      this.logger.debug(`Serving ${key} from cache.`);
      return entry.value;
    }
    const value = await produce();
    this.cache.set(key, { value, expiresAt: Date.now() + CACHE_TTL_MS2 });
    return value;
  }
  async fetchSeatMapPayload(slug) {
    const payload = await this.request(`${this.baseUrl}/${slug}`, { Accept: "text/x-component", RSC: "1" }, slug);
    if (payload.includes(SEAT_MAP_MARKER2)) {
      return payload;
    }
    return this.request(`${this.baseUrl}/${slug}`, { Accept: "text/html" }, slug);
  }
  async request(url, headers, slug) {
    const startedAt = Date.now();
    const response = await this.fetchWithRetry(url, headers);
    if (response.status === 404 && slug) {
      this.logger.debug(`AeroLOPA has no configuration ${slug}.`);
      throw new SeatMapNotFoundError(slug);
    }
    if (!response.ok) {
      this.logger.warn(`AeroLOPA answered ${response.status} for ${url}.`);
      throw new AerolopaUnavailableError2();
    }
    try {
      const body = await response.text();
      this.logger.debug(`Read ${body.length} bytes from ${url} in ${Date.now() - startedAt}ms.`);
      return body;
    } catch (error) {
      this.logger.warn(`Could not read the AeroLOPA response from ${url}: ${describeError2(error)}`);
      throw new AerolopaUnavailableError2();
    }
  }
  async fetchWithRetry(url, headers) {
    for (let attempt = 0; attempt <= RETRIES2; attempt++) {
      try {
        return await fetch(url, {
          headers: { "User-Agent": this.userAgent, ...headers },
          signal: AbortSignal.timeout(TIMEOUT_MS2)
        });
      } catch (error) {
        if (attempt === RETRIES2) {
          this.logger.error(`Could not reach ${url} in ${RETRIES2 + 1} attempts: ${describeError2(error)}`);
          throw new AerolopaUnavailableError2();
        }
        const backoff = BACKOFF_MS2 * 2 ** attempt;
        this.logger.warn(
          `Attempt ${attempt + 1} to reach ${url} failed: ${describeError2(error)}. Retrying in ${backoff}ms.`
        );
        await delay2(backoff);
      }
    }
    throw new AerolopaUnavailableError2();
  }
};

// ../packages/aerolopa/seatmap/src/handler.ts
var OPERATIONS = ["seatmap", "resolve", "configurations"];
var logger3 = new Logger2("SeatmapHandler");
function isTruthy(value) {
  return value === true || value === "true" || value === "1";
}
__name(isTruthy, "isTruthy");
function inferOperation(params) {
  if (params.op) {
    if (!OPERATIONS.includes(params.op)) {
      throw new BadRequestError(`Unknown operation "${params.op}". Expected one of ${OPERATIONS.join(", ")}.`);
    }
    return params.op;
  }
  if (params.slug) {
    return "seatmap";
  }
  if (params.airline || params.aircraft) {
    return "resolve";
  }
  throw new BadRequestError("Provide slug, or airline and aircraft, or op=configurations.");
}
__name(inferOperation, "inferOperation");
async function seatMapOperation(client3, params) {
  if (!params.slug) {
    throw new BadRequestError("Parameter slug is required for op=seatmap.");
  }
  const seatMap = await client3.getSeatMap(params.slug);
  return { statusCode: 200, body: { seatMap } };
}
__name(seatMapOperation, "seatMapOperation");
async function resolveOperation(client3, params) {
  if (!params.airline || !params.aircraft) {
    throw new BadRequestError("Parameters airline and aircraft are required for op=resolve.");
  }
  const candidates = await client3.findConfigurations(params.airline, params.aircraft);
  const seatMaps = isTruthy(params.includeSeatMaps) ? await collectSeatMaps(client3, candidates) : [];
  const result = {
    airlineIata: params.airline.toUpperCase(),
    aircraftIata: params.aircraft.toUpperCase(),
    candidateCount: candidates.length,
    ambiguous: candidates.length > 1,
    candidates: candidates.map((candidate) => candidate.slug),
    seatMaps
  };
  return { statusCode: 200, body: result };
}
__name(resolveOperation, "resolveOperation");
async function collectSeatMaps(client3, candidates) {
  const seatMaps = [];
  for (const candidate of candidates) {
    seatMaps.push(await client3.getSeatMap(candidate.slug));
  }
  return seatMaps;
}
__name(collectSeatMaps, "collectSeatMaps");
async function configurationsOperation(client3) {
  const configurations = await client3.listConfigurations();
  return {
    statusCode: 200,
    body: { count: configurations.length, configurations }
  };
}
__name(configurationsOperation, "configurationsOperation");
function describeRequest(operation, params) {
  const details = [
    params.slug ? `slug=${params.slug}` : "",
    params.airline ? `airline=${params.airline}` : "",
    params.aircraft ? `aircraft=${params.aircraft}` : "",
    isTruthy(params.includeSeatMaps) ? "includeSeatMaps=true" : ""
  ].filter(Boolean);
  return [`op=${operation}`, ...details].join(" ");
}
__name(describeRequest, "describeRequest");
async function execute(client3, operation, params) {
  switch (operation) {
    case "seatmap":
      return await seatMapOperation(client3, params);
    case "resolve":
      return await resolveOperation(client3, params);
    case "configurations":
      return await configurationsOperation(client3);
  }
}
__name(execute, "execute");
async function handleRequest2(client3, params) {
  const startedAt = Date.now();
  let operation = "unknown";
  try {
    operation = inferOperation(params);
    const response = await execute(client3, operation, params);
    logger3.log(`Served ${describeRequest(operation, params)} in ${Date.now() - startedAt}ms.`);
    return response;
  } catch (error) {
    if (error instanceof ProviderError2) {
      logger3.warn(
        `Request ${describeRequest(operation, params)} failed after ${Date.now() - startedAt}ms with ${error.status} ${error.code}: ${error.message}`
      );
      return {
        statusCode: error.status,
        body: {
          error: {
            code: error.code,
            message: error.message,
            status: error.status
          }
        }
      };
    }
    logger3.error(
      `Request ${describeRequest(operation, params)} crashed after ${Date.now() - startedAt}ms: ${describeError2(error)}`,
      stackOf2(error)
    );
    return {
      statusCode: 500,
      body: {
        error: {
          code: "INTERNAL_ERROR",
          message: "Seat map lookup failed.",
          status: 500
        }
      }
    };
  }
}
__name(handleRequest2, "handleRequest");

// ../packages/aerolopa/seatmap/src/function.ts
var DEFAULT_BASE_URL2 = "https://www.aerolopa.com";
var DEFAULT_USER_AGENT2 = "MyPreflight/1.0 (+https://mypreflight.io)";
var logger4 = new Logger2("SeatmapFunction");
var client2;
function resolveClient2() {
  if (!client2) {
    const baseUrl = process.env.AEROLOPA_API_HOST ?? DEFAULT_BASE_URL2;
    client2 = new AerolopaClient2({
      baseUrl,
      userAgent: process.env.AEROLOPA_USER_AGENT ?? DEFAULT_USER_AGENT2
    });
    logger4.log(`Cold start. Reading seat maps from ${baseUrl}.`);
  }
  return client2;
}
__name(resolveClient2, "resolveClient");
async function main2(args) {
  const { statusCode, body } = await handleRequest2(resolveClient2(), args);
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body
  };
}
__name(main2, "main");

// ../packages/aerolopa/seatmap/src/lambda.ts
var SECRET_HEADER2 = "x-require-whisk-auth";
var UNAUTHORIZED2 = {
  statusCode: 401,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    error: {
      code: "UNAUTHORIZED",
      message: "The X-Require-Whisk-Auth header is missing or wrong.",
      status: 401
    }
  })
};
function isAuthorized2(received) {
  const secret = process.env.AEROLOPA_FUNCTION_SECRET ?? "";
  if (secret === "" || received === void 0) {
    return false;
  }
  const expected = Buffer.from(secret);
  const actual = Buffer.from(received);
  return expected.length === actual.length && (0, import_node_crypto2.timingSafeEqual)(expected, actual);
}
__name(isAuthorized2, "isAuthorized");
function createHandler2(entry) {
  return async (event) => {
    if (!isAuthorized2(event.headers?.[SECRET_HEADER2])) {
      return UNAUTHORIZED2;
    }
    const args = { ...event.queryStringParameters, __ow_method: event.requestContext.http.method.toLowerCase() };
    const { statusCode, headers, body } = await entry(args);
    return { statusCode, headers, body: typeof body === "string" ? body : JSON.stringify(body) };
  };
}
__name(createHandler2, "createHandler");
var handler2 = createHandler2(main2);

// src/index.ts
var ROUTES = /* @__PURE__ */ new Map([
  ["/seatmap", handler2],
  ["/layouts", handler]
]);
var NOT_FOUND = {
  statusCode: 404,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    error: {
      code: "NOT_FOUND",
      message: `Unknown function. Expected one of ${[...ROUTES.keys()].join(", ")}.`,
      status: 404
    }
  })
};
async function handler3(event) {
  const route = ROUTES.get(event.rawPath);
  return route ? await route(event) : NOT_FOUND;
}
__name(handler3, "handler");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
